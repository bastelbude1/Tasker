# TEST_METADATA: {"description": "Minimal task example with only required parameters", "test_type": "positive", "expected_exit_code": 0, "expected_success": true, "expected_execution_path": [0], "expected_final_task": 0}

# Minimal task example - only required parameters
task=0
hostname=localhost
command=date
exec=local
